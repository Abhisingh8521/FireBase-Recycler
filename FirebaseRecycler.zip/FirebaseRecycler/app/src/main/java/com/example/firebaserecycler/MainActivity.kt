package com.example.firebaserecycler

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


class MainActivity : AppCompatActivity(), OnitemClick {


    private val db = Firebase.firestore
    private val data = ArrayList<DataModelClass>()
    private lateinit var recyclerview: RecyclerView
    private lateinit var documentArrayId: ArrayList<Any>

    @SuppressLint("SuspiciousIndentation", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerview = findViewById<RecyclerView>(R.id.recyclerview)
        documentArrayId = ArrayList()


        //delete Array
        val btn = findViewById<Button>(R.id.btn)
        db.collection("Order").get()
            .addOnSuccessListener {

                val store = it.toObjects(DataModelClass::class.java)
                data.addAll(store)

                for (i in it.documents) {
                    documentArrayId.add(i.id)
                }

            }
            .addOnFailureListener {
                Toast.makeText(this, "Fail", Toast.LENGTH_SHORT).show()
            }

        btn.setOnClickListener {
            recyclerview.layoutManager = LinearLayoutManager(this)

            recyclerview.adapter = RecyclerAdapter(data, this)
        }

//send Activity SignupActivity
        val find = findViewById<Button>(R.id.addbtn)
        find.setOnClickListener {
            startActivity(Intent(this, SignnUpFirebase::class.java))
        }

    }

    //delete from
    override fun onClick(position: Int, view: View) {

        view.findViewById<TextView>(R.id.upbtn).setOnClickListener{
            startActivity(Intent(this,UpdateData::class.java))
        }
        val deletebtn = view.findViewById<TextView>(R.id.delete_data)
        deletebtn.setOnClickListener {
            val curreDocumentId = documentArrayId[position]
            db.collection("Order")
                .document(curreDocumentId.toString()).delete()
                .addOnSuccessListener {
                    Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
                    data.removeAt(position)
                    documentArrayId.removeAt(position)
                    recyclerview.adapter = RecyclerAdapter(data, this)

                }
        }

    }

}