package com.example.firebaserecycler

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import io.grpc.Context


class RecyclerAdapter(val list: ArrayList<DataModelClass>, private val interf:OnitemClick) :RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val name: TextView = itemView.findViewById(R.id.namee)
        val address: TextView = itemView.findViewById<TextView>(R.id.address)
        val contact: TextView = itemView.findViewById<TextView>(R.id.contact)
        val date: TextView = itemView.findViewById<TextView>(R.id.date)
        val email: TextView = itemView.findViewById<TextView>(R.id.email)
        val orderName: TextView = itemView.findViewById<TextView>(R.id.orderName)
        val prize: TextView = itemView.findViewById<TextView>(R.id.prize)

        var item=ItemView


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_design, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        interf.onClick(position,holder.item )
        val model = list[position]
        holder.name.text = model.Costumer_name
        holder.address.text = model.Order_address
        holder.contact.text = model.Order_contact.toString()
        holder.date.text = model.Order_date
        holder.email.text = model.Order_email
        holder.orderName.text = model.Order_name
        holder.prize.text=model.Order_prize.toString()

    }

    }
interface OnitemClick{
    fun onClick(position: Int,view: View)
}