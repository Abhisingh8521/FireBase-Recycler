package com.example.firebaserecycler

import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class SignnUpFirebase : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signn_up_firebase)

        val db = Firebase.firestore

        val Costumer_name = findViewById<EditText>(R.id.Costumer_name)
        val Order_address = findViewById<EditText>(R.id.Order_address)
        val Order_contact = findViewById<EditText>(R.id.Order_contact)
        val Order_date = findViewById<EditText>(R.id.Order_date)
        val Order_email = findViewById<EditText>(R.id.Order_email)
        val Order_name = findViewById<EditText>(R.id.Order_name)
        val Order_prize = findViewById<EditText>(R.id.Order_prize)
        val signupbtn = findViewById<Button>(R.id.signup_btn)

        signupbtn.setOnClickListener {

            val name = Costumer_name.text.toString()
            val address = Order_address.text.toString()
            val contact = Order_contact.text.toString()
            val date = Order_date.text.toString()
            val email = Order_email.text.toString()
            val O_name = Order_name.text.toString()
            val prize = Order_prize.text.toString()

            when {
                name.isEmpty() -> {
                    Costumer_name.error = ("Please Enter A Name")
                }
                address.isEmpty() -> {
                    Order_address.error = ("Please Enter A Address")
                }
                contact.isEmpty() -> {
                    Order_contact.error = ("Please Enter A Contact")
                }
                date.isEmpty() -> {
                    Order_date.error = ("Please Enter A Date")
                }
                email.isEmpty() -> {
                    Order_email.error = ("Please Enter A Email")
                }
                O_name.isEmpty() -> {
                    Order_name.error = ("Please Enter A Name")
                }
                prize.isEmpty() -> {
                    Order_prize.error = ("Please Enter A Prize")
                }

                else -> {


                    val add = HashMap<String, Any>()
                    add["Costumer_name"] = name
                    add["Order_address"] = address
                    add["Order_contact"] = contact
                    add["Order_date"] = date
                    add["Order_email"] = email
                    add["Order_name"] = O_name
                    add["Order_prize"] = prize

                    db.collection("Order")

                        .add(add)
                        .addOnSuccessListener {
                            Toast.makeText(this, "ADD DATA", Toast.LENGTH_SHORT).show()
                            startActivity(Intent(this, MainActivity::class.java))

                        }
                        .addOnFailureListener {
                            Toast.makeText(this, " Data not added ", Toast.LENGTH_LONG).show()
                        }


                }
            }
        }
    }}