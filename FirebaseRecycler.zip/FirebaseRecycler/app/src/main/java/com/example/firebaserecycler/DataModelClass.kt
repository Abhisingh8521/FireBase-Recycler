package com.example.firebaserecycler

data class DataModelClass(
    val Costumer_name: String? = null,
    val Order_address: String? = null,
    val Order_contact: String? = null,
    val Order_date: String? = null,
    val Order_email: String? = null,
    val Order_name: String? = null,
    val Order_prize: String? = null

)
