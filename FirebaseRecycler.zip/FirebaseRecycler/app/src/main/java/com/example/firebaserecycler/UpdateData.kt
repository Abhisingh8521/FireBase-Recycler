package com.example.firebaserecycler

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class UpdateData : AppCompatActivity() {

    val db = Firebase.firestore
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_data)




//        val up_name = findViewById<EditText>(R.id.up_name)
//        val up_address = findViewById<EditText>(R.id.up_address)
//        val up_contact = findViewById<EditText>(R.id.up_contact)
//        val up_date = findViewById<EditText>(R.id.up_date)
//        val up_email = findViewById<EditText>(R.id.up_email)
//        val upp_name = findViewById<EditText>(R.id.upp_name)
//        val up_prize = findViewById<EditText>(R.id.up_prize)
//        val up_btn = findViewById<Button>(R.id.up_btn)
//
//        up_btn.setOnClickListener {
//            val name=up_name.text.toString()
//
//        }
    }
}